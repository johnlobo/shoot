#include <string.h>

/*****************************************************/
/*													 */
/*	Convert int to string							 */
/*												     */
/*****************************************************/
void ConvertIntToChar(int pNum, char* pStr)
{
    int i, rem, len = 0, n, off = 0;
	
	n = pNum;
    while (n != 0)
    {
        len++;
        n /= 10;
    }
	
	if (pNum < 0)
	{
		off = 1;
		pStr[0] = '-';		
		pNum = -pNum;
	}	
		
    for (i = 0; i < len; i++)
    {
        rem = pNum % 10;
        pNum = pNum / 10;
        pStr[len - (i + 1) + off] = rem + '0';
    }
}

/*****************************************************/
/*													 */
/*	Display char							 		 */
/*												     */
/*****************************************************/
void DisplayChar(char c)
{
c;
__asm
	PUSH IX         ; Save IX before making changes
	LD IX, #0       ; IX points to the top of the stack: 
	ADD IX, SP      ;  1st parameter is IX+4, as we have IX (2 bytes) + Return Address (2 bytes) in the stack

    LD A, 4(IX)
    CALL #0xbb5a
	
	POP IX       ; Restore IX before returning
__endasm;
}

/*****************************************************/
/*													 */
/*	Display String							 		 */
/*												     */
/*****************************************************/
void PrintStr(const char* pText)
{
    while(*pText != 0)
    {
		DisplayChar(*pText);
        pText++;
    }
}

/*****************************************************/
/*													 */
/*	Display Hexa							 		 */
/*												     */
/*****************************************************/
void PrintHexa(unsigned int b) 
{
	static const char hexaChars[] = "0123456789ABCDEF";
	char hexa[8];

	hexa[0] = '0';
	hexa[1] = 'x';
    hexa[2] = hexaChars[( b >> 12 ) & 0x0F];
    hexa[3] = hexaChars[( b >> 8 ) & 0x0F];
	hexa[4] = hexaChars[( b >> 4 ) & 0x0F];
    hexa[5] = hexaChars[b & 0x0F];
	hexa[6] = ' ';
	hexa[7] = '\0';
	
	PrintStr(hexa);
}

/*****************************************************/
/*													 */
/*	Display Int							 			 */
/*												     */
/*****************************************************/
void PrintInt(int pInt)
{		
	char conv[7] = {'0','\0'};
	if (pInt != 0)
	{
		memset(conv, 0, 7);
		ConvertIntToChar(pInt, conv);
	}
	PrintStr(conv);	
	PrintStr(" ");
}

/*****************************************************/
/*													 */
/*	Debug stop						 				 */
/*												     */
/*****************************************************/
/*void Debug(char* pStr, int pValue)
{
	PrintStr(pStr);
	PrintInt(pValue);
	while(1){};
}*/
